/**
 * 
 */
/**
 * 
 */
module sm2Webshop {
	requires org.junit.jupiter.api;
}